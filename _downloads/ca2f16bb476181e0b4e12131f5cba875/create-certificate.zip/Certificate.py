from xhtml2pdf import pisa
from chameleon import PageTemplateFile

template = PageTemplateFile("Certificate.html")


def write_certificate(filename: str, **kwargs):
    html = template.render(**kwargs)
    with open(filename, 'wb') as fp:
        pisa.CreatePDF(html, dest=fp)