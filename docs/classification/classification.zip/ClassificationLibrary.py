from appdirs import user_data_dir
from contextlib import contextmanager
from river.naive_bayes import MultinomialNB
from river.feature_extraction import BagOfWords
from river.compose import Pipeline 
from robot.api.deco import keyword, library
from robot.api import logger

import appdirs
import os
import pathlib
import pickle


@contextmanager
def pipeline(name):
    appdir = pathlib.Path(user_data_dir("river-models", "rcc"))
    appdir.mkdir(parents=True, exist_ok=True)
    path = appdir / f"{name}.pkl"
    model = pickle.loads(path.read_bytes()) \
        if path.exists() \
        else Pipeline(
            ("tokenize", BagOfWords(lowercase=True)),
            ("nb", MultinomialNB())
        )
    yield model
    path.write_bytes(pickle.dumps(model))


@library
class ClassificationLibrary:
    @keyword
    def train(self, model, text, klass):
        with pipeline(model) as machine:
            machine.learn_one(text, klass)

    @keyword
    def predict(self, model, text):
        with pipeline(model) as machine:
             return sorted(
                (machine.predict_proba_one(text) or {}).items(),
                key=lambda x: x[-1],
                reverse=True,
             )